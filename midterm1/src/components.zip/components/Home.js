import React from 'react';
import { useTheme } from './theme';

const Home = () => {
    return (
        <div className="">
            <h1 className="">Welcome to our Home Page!</h1>
            <p></p>
        </div>
    );
};

export default Home;