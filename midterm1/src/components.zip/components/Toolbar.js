import React from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from './theme';

const Toolbar = () => {
    return (
        <nav>
            <Link to="/">Home</Link> | <Link to="/products">Products</Link> | <Link to="/main-program">Theme</Link>
            
        </nav>
    );
};

export default Toolbar;