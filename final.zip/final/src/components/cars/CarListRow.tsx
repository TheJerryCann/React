import React from 'react';
import { Card } from '../Card';
import { Thumbnail } from '../Thumbnail';
import { Link } from 'react-router-dom';

interface Product {
    id: number;
    title: string;
    price: number;
    description: string;
    category: string;
    image: string;
    rating: Rating;
}

interface Rating {
    rate: number;
    count: number;
}

interface Props {
    product: Product;
}

export const CarListRow: React.FC<Props> = ({ product }) => {
    return (
        <Card
        >
            <Thumbnail  price={product.price} description={product.description} image={product.image} />
            <Link to={`/cars/${product.id}`}>
                {product.title}
            </Link>
            <p>${product.price}</p>
        </Card>
    );
};
