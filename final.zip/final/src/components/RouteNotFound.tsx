import React from 'react';

export const RouteNotFound: React.FC = () => {
    return (
        <div>
            <p>Route not found</p>
        </div>
    );
};
