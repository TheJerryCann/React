import './App.css';
import { Layout } from './components/Layout';

function App(): JSX.Element {
    return (
        <div className="App">
            <Layout />
        </div>
    );
}

export default App;
